<?php
return [
    'APP_URL' => env('APP_URL')

];